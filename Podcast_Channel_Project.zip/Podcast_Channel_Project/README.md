## Podcast-Channel-Project
Block 1 - Acámica Coding Bootcamp Project/ 
The challenge is focused on the layout of the landing page of a Podcast channel, 
following the visual guidelines of a given user interface and developing functionalities for content playback, 
navigation, compatibility with multiple browsers and devices.
Check it [here!](https://asj-code.github.io/Podcast-Channel/)./ 
